var t, a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/tools.js")), e = getApp();

Page({
    data: {
        page: 1,
        isover: !1,
        pdd_keyword: "",
        top_h: 62
    },
    onLoad: function(a) {
        (t = this).setData({
            top_h: e.globalData.nav_height ? e.globalData.nav_height : 62
        });
    },
    inputText: function(a) {
        t.setData({
            pdd_keyword: a.detail.value
        });
    },
    clearInput: function() {
        t.setData({
            pdd_keyword: ""
        });
    },
    search_btn: function() {
        this.setData({
            isover: !1,
            pddGoodsList: [],
            page: 1
        }), t.loadGoods();
    },
    nav_sarc: function(a) {
        var e = a.currentTarget.dataset.contents;
        t.setData({
            pdd_keyword: e,
            isover: !1,
            pddGoodsList: [],
            page: 1
        }), t.loadGoods();
    },
    click_nav_det: function(t) {
        var a = t.currentTarget.dataset.goods_id;
        wx.navigateTo({
            url: "/bh_cat/pages/pdd_details/pdd_details?goods_id=" + a
        });
    },
    loadGoods: function() {
        var e = {
            action: "goods",
            contr: "pdd",
            token: wx.getStorageSync("token"),
            page: t.data.page,
            pdd_keyword: this.data.pdd_keyword
        };
        a.default.request(e, function(a) {
            var e = a.info.pddGoodsList;
            t.data.page > 1 && (e = t.data.pddGoodsList.concat(e)), t.setData({
                pddGoodsList: e
            }), a.info.pddGoodsList < 10 && t.setData({
                isover: !0
            });
        });
    },
    onReachBottom: function() {
        this.data.isover || (this.data.page++, this.loadGoods());
    },
    onReady: function() {
        wx.createSelectorQuery().select("#global-nav").boundingClientRect(function(a) {
            console.log(a.height), t.setData({
                m_height: a.height
            });
        }).exec();
        var e = {
            action: "popular",
            contr: "pdd",
            token: wx.getStorageSync("token")
        };
        a.default.request(e, function(a) {
            t.setData(a.info);
        });
    },
    onShow: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.share.text,
            imageUrl: this.data.share.images,
            path: "bh_cat/pages/index/index?parent_id=" + this.data.share.member_id
        };
    }
});