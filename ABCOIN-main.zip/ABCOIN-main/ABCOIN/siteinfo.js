var e = {
    name: "we7_wxappdemo",
    uniacid: "42",
    acid: "42",
    multiid: "0",
    version: "1.0.0",
    siteroot: "https://we.linknew.cn/app/index.php",
    method_design: "3"
};

module.exports = e;