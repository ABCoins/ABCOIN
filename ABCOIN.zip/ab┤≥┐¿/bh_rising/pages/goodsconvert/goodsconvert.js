var t, e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../utils/tools.js"));

getApp();

Page({
    data: {},
    onLoad: function(e) {
        t = this;
    },
    onReady: function() {},
    onUnload: function() {},
    onHide: function() {},
    onShow: function() {
        var n = {
            action: "index",
            contr: "shop",
            token: wx.getStorageSync("token")
        };
        e.default.request(n, function(e) {
            t.setData(e.info);
        });
    },
    goodsDetails: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/bh_rising/pages/goods/goods?id=" + e
        });
    },
    gotoSgin: function() {
        wx.navigateTo({
            url: "/bh_rising/pages/order/order"
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.share.text,
            imageUrl: this.data.share.images,
            path: "bh_rising/pages/index/index?parent_id=" + this.data.share.member_id
        };
    }
});