Component({
    properties: {
        list: {
            type: Object
        },
        bdColor: {
            type: String,
            value: "#c8c8c8"
        },
        color: {
            type: String,
            value: "#333333"
        },
        selectedColor: {
            type: String,
            value: "#09B36C"
        },
        zIndex: {
            type: Number,
            value: 100
        },
        selection: {
            type: String,
            value: "index"
        }
    },
    data: {
        nowIndex: 0,
        isIphonex: !1
    },
    ready: function() {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.screenFix(t);
            }
        });
    },
    methods: {
        navigatorSwitch: function(e) {
            var t = e.currentTarget.dataset.index;
            this.data.list[t].selectd || wx.reLaunch({
                url: this.data.list[t].path
            }), console.log(e);
        },
        switchNavigator: function(e, t) {
            var n = e.dataset, a = n.index, i = n.pageIndex, o = n.pageName;
            this.setData({
                nowIndex: a
            }), t && this.triggerEvent("navigatorSwitch", {
                index: a,
                pageIndex: i,
                pageName: o
            });
        },
        setActiveIndex: function(e) {
            this.setData({
                nowIndex: e
            });
        },
        screenFix: function(e) {
            console.log("当前系统消息", e), "getSystemInfo:ok" == e.errMsg && -1 != e.model.toLowerCase().indexOf("iphone x") && this.setData({
                isIphonex: !0
            });
        }
    }
});